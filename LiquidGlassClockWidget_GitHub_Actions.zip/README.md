# Liquid Glass Clock Widget

A minimal Android home-screen clock widget inspired by the supplied reference image.

## Features
- 24-hour clock (`HH:mm`)
- Large thin digits
- Transparent widget background
- Dark grey translucent-looking digits with subtle highlight/shadow
- Automatic update at the start of each minute
- Resizable home-screen widget
- No app UI or extra buttons

## Open in Android Studio
1. Extract/open this project in Android Studio.
2. Let Gradle sync.
3. Run the app on an Android 8.0+ device/emulator.
4. Long-press the home screen -> Widgets -> Liquid Glass Clock.
5. Resize the widget until the proportions match your wallpaper.

## Notes
The exact appearance can vary slightly between launchers because Android widget hosts control some rendering and scaling. The project intentionally uses a transparent widget background so the wallpaper remains visible behind the clock.

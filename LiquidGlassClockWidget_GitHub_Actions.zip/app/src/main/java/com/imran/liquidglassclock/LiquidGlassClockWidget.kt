package com.imran.liquidglassclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LiquidGlassClockWidget : AppWidgetProvider() {

    companion object {
        private const val ACTION_UPDATE = "com.imran.liquidglassclock.UPDATE_CLOCK"

        private fun updateWidgets(context: Context, ids: IntArray) {
            val manager = AppWidgetManager.getInstance(context)

            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.widget_liquid_glass_clock)
                views.setTextViewText(R.id.clock_text, time)
                manager.updateAppWidget(id, views)
            }
        }

        private fun scheduleNextMinute(context: Context) {
            val alarmManager = context.getSystemService(AlarmManager::class.java)
            val intent = Intent(context, LiquidGlassClockWidget::class.java).apply {
                action = ACTION_UPDATE
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                1001,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Fire just after the next minute starts.
            val now = System.currentTimeMillis()
            val nextMinute = ((now / 60_000L) + 1L) * 60_000L + 250L

            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                nextMinute,
                pendingIntent
            )
        }

        private fun cancelClockAlarm(context: Context) {
            val alarmManager = context.getSystemService(AlarmManager::class.java)
            val intent = Intent(context, LiquidGlassClockWidget::class.java).apply {
                action = ACTION_UPDATE
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                1001,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarmManager.cancel(pendingIntent)
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        updateWidgets(context, appWidgetIds)
        scheduleNextMinute(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)

        when (intent.action) {
            ACTION_UPDATE,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(
                    android.content.ComponentName(context, LiquidGlassClockWidget::class.java)
                )
                if (ids.isNotEmpty()) {
                    updateWidgets(context, ids)
                    scheduleNextMinute(context)
                }
            }
        }
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        super.onDeleted(context, appWidgetIds)

        val manager = AppWidgetManager.getInstance(context)
        val remaining = manager.getAppWidgetIds(
            android.content.ComponentName(context, LiquidGlassClockWidget::class.java)
        )

        if (remaining.isEmpty()) {
            cancelClockAlarm(context)
        }
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        cancelClockAlarm(context)
    }
}
